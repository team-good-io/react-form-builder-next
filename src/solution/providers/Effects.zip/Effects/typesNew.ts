// Engine

export interface EffectState {
  fieldProps?: Record<string, unknown>;
  registerProps?: Record<string, unknown>;
}

// Config

export type EffectCondition = {
  field: string;
  operator: '===' | '!==' | '>' | '<' | 'in';
  value: unknown;
};

export type EffectAction =
  | { type: 'setValue'; target: string; value: unknown }
  | { type: 'setValidation'; target: string; schema: Record<string, unknown> }
  | { type: 'resetField'; target: string }
  | { type: 'showField'; target: string }
  | { type: 'hideField'; target: string }
  | { type: 'clearErrors'; target: string };

  export type EffectRule = {
    when: EffectCondition[];
    actions: EffectAction[];
  };
  
  export type EffectsConfig = EffectRule[];

  export interface EffectsToolbox {
    setValue: (name: string, value: unknown) => void;
    resetField: (name: string) => void;
    clearErrors: (name: string) => void;
    // next: add showField / hideField hooks here for full future-proofing
  }