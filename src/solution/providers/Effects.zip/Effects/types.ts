// Engine

export interface EffectState {
  fieldProps?: Record<string, unknown>;
  registerProps?: Record<string, unknown>;
}

export interface EffectField {
  name: string;
  value: unknown;
  options?: unknown;
}

// Config

export interface Effect {
  fieldProps?: Record<string, unknown>;
  registerProps?: Record<string, unknown>;
  setValue?: string | number | boolean;
  resetField?: boolean;
  setValueFromOptions?: {
    valueKey: string;
  };
}

export interface EffectRule {
  sourceValue: string;
  targetNames: string[];
  effect: Effect
}

export type EffectsConfig = Record<string, EffectRule[]>