import { EffectField } from "../../types";

export const getValueFromOptions = (
  source: EffectField,
  valueKey: string,
  optionsMap: Map<string, unknown>,
): unknown => {
  const option = optionsMap?.get(source.name)?.data?.find(({ value }) => value === source.value);
  if (option && valueKey && option[valueKey]) {
    return option[valueKey];
  }
  return undefined;
};
