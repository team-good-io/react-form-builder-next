import type { EffectAction, EffectCondition, EffectsConfig, EffectsToolbox } from '../typesNew';

export function createEffectsEngine(
  config: EffectsConfig,
  toolbox: EffectsToolbox
) {
  const evaluateCondition = (condition: EffectCondition, formValues: Record<string, unknown>): boolean => {
    const fieldValue = formValues[condition.field];

    switch (condition.operator) {
      case '===':
        return fieldValue === condition.value;
      case '!==':
        return fieldValue !== condition.value;
      case '>':
        return typeof fieldValue === 'number' && fieldValue > (condition.value as number);
      case '<':
        return typeof fieldValue === 'number' && fieldValue < (condition.value as number);
      case 'in':
        return Array.isArray(condition.value) && condition.value.includes(fieldValue);
      default:
        console.warn(`Unsupported operator: ${condition.operator}`);
        return false;
    }
  };

  const executeAction = (action: EffectAction) => {
    switch (action.type) {
      case 'setValue':
        toolbox.setValue(action.target, action.value);
        break;

      case 'resetField':
        toolbox.resetField(action.target);
        break;

      case 'clearErrors':
        toolbox.clearErrors(action.target);
        break;

      case 'setValidation':
        // Option 1: emit via pubsub for validation engine
        // Option 2: integrate later with resolver or internal registry
        console.warn('setValidation is not implemented yet');
        break;

      case 'showField':
      case 'hideField':
        // Future: publish to UI visibility context
        console.warn(`${action.type} is not implemented yet`);
        break;
      default: {
        console.warn(`Unknown action: ${JSON.stringify(action)}`);
        // Exhaustive check
        const exhaustiveCheck: never = action;
        console.log(exhaustiveCheck);
      }
    }
  };

  const runEffects = (changedField: string, formValues: Record<string, unknown>) => {
    config.forEach(rule => {
      const isRelated = rule.when.some(condition => condition.field === changedField);
      if (!isRelated) return;

      const allConditionsMet = rule.when.every(condition => evaluateCondition(condition, formValues));
      if (!allConditionsMet) return;

      rule.actions.forEach(executeAction);
    });
  };

  return { runEffects };
}
