import { CreatePubSubProps } from "../../../services/pubSub/createPubSub";
import { EffectsConfig, EffectState } from "../types";
import { createEffectApplier } from "./createEffectApplier";
import { generateEffects } from "./generateEffects";

export function createEffectsEngine(
  config: EffectsConfig,
  pubsub: CreatePubSubProps<EffectState>,
  getOptions: () => Map<string, unknown>,
  setValue: (name: string, value: unknown) => void,
  resetField: (name: string) => void,
) {
  const applyEffect = createEffectApplier({ setValue, resetField, getOptions})

  const execute = (sourceName: string, formValues: Record<string, unknown>): void => {
    if(!config[sourceName]) return;
    const effects = generateEffects(config, sourceName, formValues);
    if(!effects.length) return;
    effects.forEach(({ source, targets, effect }) => {
      const props = applyEffect(source, targets, effect);
      targets.forEach(({name}) => pubsub.publish(name, props));
    })
  }

  const init = (values:  Record<string, unknown>) => {
    Object.keys(config).forEach((sourceName) => {
      execute(sourceName, values);
    })
  }

  const getDependencies = (): string[] => Object.keys(config)

  const onDepsChange = (name: string, values: Record<string, unknown>) => {
    execute(name, values);
  }

  return {
    init,
    getDependencies,
    onDepsChange,
  }
}