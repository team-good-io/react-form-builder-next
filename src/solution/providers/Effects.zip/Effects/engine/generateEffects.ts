import { EffectField, EffectsConfig } from "../types";

export const generateEffects = (config: EffectsConfig, sourceName: string, formValues: Record<string, unknown>) => {
  const sourceValue = formValues[sourceName];
  const rules = config[sourceName] || [];
  const source: EffectField = { name: sourceName, value: sourceValue };

  const isMatch = (ruleValue: string | RegExp): boolean => {
    if (ruleValue instanceof RegExp) {
      return ruleValue.test(String(sourceValue));
    }

    switch (ruleValue) {
      case 'HAS_VALUE':
        return Boolean(sourceValue);
      case 'NO_VALUE':
        return !sourceValue;
      default:
        return ruleValue === sourceValue;
    }
  };

  return rules.flatMap((rule) => {
    if (!isMatch(rule.sourceValue)) return [];

    const targets: EffectField[] = rule.targetNames.map((targetName) => ({
      name: targetName,
      value: formValues[targetName],
    }));

    return [{ source, targets, effect: rule.effect }];
  });
};
