import type { Effect, EffectField } from '../types';
import { getValueFromOptions } from './utils/getValueFromOptions';
// import { getValueFromRemote } from '../utils/getValueFromRemote';

export const createEffectApplier = ({ setValue, resetField, getOptions }: {
  getOptions: () => Map<string, unknown>;
  setValue: (name: string, value: unknown) => void;
  resetField: (name: string) => void;
}) => (source: EffectField, targets: EffectField[], effect: Effect) => {
  if (effect.setValue !== undefined) {
    targets.forEach(({ name }) => setValue(name, effect.setValue));
  }

  if (effect.resetField) {
    targets.forEach(({ name }) => resetField(name));
  }

  if (effect.setValueFromOptions) {
    const value = getValueFromOptions(source, effect.setValueFromOptions.valueKey, getOptions());
    if (value !== undefined) {
      targets.forEach(({ name }) => setValue(name, value));
    }
  }

  // if (effect.setValueFromZipCodeRemote) {
  //   getValueFromRemote(source, effect.setValueFromZipCodeRemote).then((result) => {
  //     if (result) {
  //       targets.forEach(({ name }) => {
  //         const value = result[name];
  //         if (value !== undefined) {
  //           setValue(name, value as string);
  //         }
  //       });
  //     }
  //   });
  // }

  return {
    registerProps: effect.registerProps ?? {},
    fieldProps: effect.fieldProps ?? {},
  };
};
