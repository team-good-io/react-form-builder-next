import { useEffect, useMemo } from "react";
import createPubSub from "../../services/pubSub/createPubSub";
import { EffectsContext } from "./EffectsContext";
import { EffectsConfig, EffectState } from "./types";
import { createEffectsEngine } from "./engine/createEffectsEngine";
import { useFormContext } from "react-hook-form";
import { useOptionsContext } from "../Options";

interface EffectsProviderProps {
  config: EffectsConfig;
  children: React.ReactNode;
}

export function EffectsProvider({ config, children }: EffectsProviderProps) {
  const { watch, getValues, setValue, resetField } = useFormContext();
  const { getValues: getOptions } = useOptionsContext();
  const pubsub = useMemo(() => createPubSub<EffectState>(), []);
  const engine = useMemo(
    () => createEffectsEngine(config, pubsub, getOptions, setValue, resetField),
    [config, getOptions, pubsub, resetField, setValue]
  );
  const dependencies = useMemo(() => engine.getDependencies(), [engine]);

  useEffect(() => {
    engine.init(getValues());
  }, [engine, getValues]);

  useEffect(() => {
    const { unsubscribe } = watch((values, { name }) => {
      if (name && dependencies.includes(name)) {
        engine.onDepsChange(name, values);
      }
    });
    return () => unsubscribe();
  }, [watch, dependencies, engine])

  return (
    <EffectsContext.Provider value={pubsub}>
      {children}
    </EffectsContext.Provider>
  )
}